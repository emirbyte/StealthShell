import sys
import time
import os 
def print_slow(str):
    for letter in str:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.1)
print_slow(" > Installing Packages")

os.system("clear")
os.system("apt install figlet ruby")
os.system("gem install lolcat")
os.system("clear")
os.system("echo StealthShell | figlet | lolcat -a -d 7") 

def print_slow(str):
    for letter in str:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.1)
print_slow("Made By emirbyte | Illegal use is not allowed") 

time.sleep(4)
os.system("clear")
os.system("echo Main Menu | figlet | lolcat")

choice = input(""" 


               [A] StealthShell
               [C] Exit



""")
if choice == "A" or choice == "a":
 os.system("echo StealthShell Menu | figlet | lolcat")
 IP = input(" IP Address:")
 PORT = input(" Port:")
 os.system("clear")
 os.system("echo Info | figlet | lolcat")
 print(IP,PORT)
 input("press enter")
 os.system("clear") 
 time.sleep(5)
 print_slow("Checking Ip")
 time.sleep(3) 
 print_slow("""


Gaining Shell Access


""")
 
print_slow("""
ngnix
""")
os.system("python3 modules/moduleshell.py") 

